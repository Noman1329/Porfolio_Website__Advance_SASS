const menuBtn= document.querySelector('.menu-btn');
const BurgerBtn= document.querySelector('.menu-btn__burger');
const navMenuitem= document.querySelectorAll('.menu-nav__item')
let showMenu= false;
const nav= document.querySelector('.nav');
const navMenu= document.querySelector('.menu-nav');

menuBtn.addEventListener('click', toggleMenu);
function toggleMenu()
{
    if(!showMenu)
    {
        BurgerBtn.classList.add('open');
        nav.classList.add('open');
        navMenu.classList.add('open');
        navMenuitem.forEach(item => item.classList.add('open'));
        showMenu=true;
    }
    else
    {
        BurgerBtn.classList.remove('open');
        nav.classList.remove('open');
        navMenu.classList.remove('open');
        navMenuitem.forEach(item => item.classList.remove('open'));
        showMenu= false;
    }
}